import'package:flutter/material.dart';
import 'package:fluttercom/main.dart';

class SingleProduct extends StatelessWidget {
  final String product_name;
  final String product_picture;
  final int product_old_price;
  final int  product_price;
  SingleProduct({
    this.product_name,
    this.product_picture,
    this.product_old_price,
    this.product_price, }
    );

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'kayDjeude',
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      debugShowCheckedModeBanner: false,
      home: MyHomePage(title: 'Details Produits '),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);
  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

@override
Widget build(BuildContext context) {
  Widget my_product = new Container(
    height: 200.0,
    child: new Produit(
      images:[
        AssetImage("images/products/blazer1.jpeg"),
      ],
    ),
  );

  AppBar(   elevation: 0.1,   backgroundColor: Colors.red,   title: Text(widget.title),
    //Actions du AppBar
    actions: <Widget>[
      new IconButton(icon: Icon(Icons.search,color: Colors.white),
          onPressed: (){}),
      new IconButton(icon: Icon(Icons.shopping_cart,color: Colors.white),
          onPressed: (){})
    ],
  );
  GridTile(
  //=======Images Products ============
  child: Container(
      color: Colors.white,
      child: Image.asset(
      widget.product_details_picture,
      fit: BoxFit.cover,),
  ),
  footer: new Container(
    color: Colors.white70,
    child: ListTile(
    leading: new Text(
    widget.product_details_name,
    style: TextStyle(
    fontWeight: FontWeight.bold
    ),
  ),
    title: new Row(
    children: <Widget>[
      Expanded(
      child: new  Text(
      "${widget.product_details_price} CFA",
          style: TextStyle(
          color: Colors.red,
          fontWeight: FontWeight.bold,
          fontSize: 12.0
      )
      ),
      ),
      Expanded(
      child: new  Text(
      "${widget.product_old_details_price} CFA",
        style: TextStyle(
        color: Colors.grey,
        fontWeight: FontWeight.bold,
        decoration: TextDecoration.lineThrough,
        fontSize: 12.0
        ),
      ),
    ),
  ],
  ),
  ),
  ),
  );
  Row(
  children: <Widget>[
  Expanded(
  //=========Button Couleur===================
  child: MaterialButton(
    onPressed: (){},
    color: Colors.white,
    textColor: Colors.grey,
    elevation: 0.2,
    child: Row(
    children: <Widget>[
        Expanded(child: new Text("Couleur")),
        Expanded(child: new Icon(Icons.arrow_drop_down)),
    ],
  ),
  ),
  ),
  Expanded(
  //=========Button Taille===================
    child: MaterialButton(
      onPressed: (){
        showDialog(context: context,
        builder: (context){
          return new AlertDialog(
            title: new Text("Taille"),
            content: new Text("Choisir une Taille"),
            actions: <Widget>[
              new MaterialButton(onPressed: (){
                Navigator.of(context).pop(context);
                },
    child: new Text("Fermer"),),
    ],
  );
        });
        },
      color: Colors.white,
      textColor: Colors.grey,
      elevation: 0.2,
    child: Row(
      children: <Widget>[
        Expanded(child: new Text("Taille")),
        Expanded(child: new Icon(Icons.arrow_drop_down)),
        ],
      ),
  ),
  ),
  Expanded(
  //=========Button Qte===================
    child: MaterialButton(
      onPressed: (){},
      color: Colors.white,
      textColor: Colors.grey,
      elevation: 0.2,
      child: Row(
    children: <Widget>[
      Expanded(child: new Text("Qte")),
      Expanded(child: new Icon(Icons.arrow_drop_down)),
      ],
    ),
  ),
  )
  ],
  );
  }
